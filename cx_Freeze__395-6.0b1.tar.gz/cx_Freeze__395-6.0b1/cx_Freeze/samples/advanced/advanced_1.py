#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

sys.stdout.write('Hello from cx_Freeze Advanced #1\n\n')

module = __import__('testfreeze_1')
